//sliding animation
ScrollReveal({
  reset: true,
  distance: "80px",
  duration: 2000,
  delay: 200,
});
ScrollReveal().reveal(".left-col", { origin: "left" });
ScrollReveal().reveal(".right-col", { origin: "right" });

// counter animation

function animateCounter(element, start, end, duration) {
  const range = end - start;
  const currentTimestamp = Date.now();
  const endTimestamp = currentTimestamp + duration;

  function animation() {
    const currentTimestamp = Date.now();
    const remainingTime = Math.max(endTimestamp - currentTimestamp, 0);
    const progress = 1 - remainingTime / duration;
    const current = start + Math.floor(progress * range);
    element.textContent = current;

    if (currentTimestamp < endTimestamp) {
      requestAnimationFrame(animation);
    }
  }

  animation();
}

function handleIntersection(entries, observer) {
  entries.forEach(function (entry) {
    if (entry.isIntersecting) {
      const counterElement = entry.target;
      const startValue = parseInt(counterElement.dataset.value, 10);
      const endValue = parseInt(counterElement.textContent, 10);
      const duration = 3000; // Adjust the duration as needed

      animateCounter(counterElement, startValue, endValue, duration);
      observer.unobserve(counterElement);
    }
  });
}

// Create the Intersection Observer
const observer = new IntersectionObserver(handleIntersection, {
  threshold: 0.5,
});

const counterElements = document.querySelectorAll(".counter");

counterElements.forEach((element) => {
  observer.observe(element);
});
// Observe the counter element